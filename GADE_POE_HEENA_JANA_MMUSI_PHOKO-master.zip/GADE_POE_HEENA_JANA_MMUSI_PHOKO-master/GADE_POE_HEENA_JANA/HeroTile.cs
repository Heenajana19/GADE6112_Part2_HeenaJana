﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA.GameForm;

namespace GADE_POE_HEENA_JANA
{
    internal class HeroTile : CharacterTile
    {
        public HeroTile(Position position)
                  : base(position, 40, 5)
        {
        }

       
        public override char Display
        {
            get
            {
                if (IsDead)
                {
                    return 'x';
                }

                return '▼';
            }
        }
    }
}

