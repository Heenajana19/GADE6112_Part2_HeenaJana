﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA;
using GADE_POE_HEENA_JANA.GameForm;

namespace GADE_POE_HEENA_JANA
{
    internal class Level
    {
        private Tile[,] tiles;
        private int width;
        private int height;

        private HeroTile hero;
        private ExitTile exit;

        private Random random;

       

        public Tile[,] Tiles
        {
            get { return tiles; }
        }

        public HeroTile Hero
        {
            get { return hero; }
        }

        public ExitTile Exit
        {
            get { return exit; }
        }

        public enum TileType
        {
            Empty,
            Wall,
            Hero,
            Exit
        }
        public Level(int width, int height, HeroTile existingHero = null)
        {
            this.width = width;
            this.height = height;

            random = new Random();

            tiles = new Tile[width, height];

            InitialiseTiles();

            PlaceHero(existingHero);
            PlaceExit();

            hero.UpdateVision(this);
        }

        private bool IsBoundary(int x, int y)
        {
            if (x == 0)
            {
                return true;
            }

            if (y == 0)
            {
                return true;
            }

            if (x == width - 1)
            {
                return true;
            }

            if (y == height - 1)
            {
                return true;
            }

            return false;
        }

        private Tile CreateTile(
           TileType type,
           Position position)
        {
            Tile createdTile;

            switch (type)
            {
                case TileType.Empty:

                    createdTile =
                        new EmptyTile(position);

                    break;


                case TileType.Wall:

                    createdTile =
                        new WallTile(position);

                    break;


                case TileType.Hero:

                    createdTile =
                        new HeroTile(position);

                    break;


                case TileType.Exit:

                    createdTile =
                        new ExitTile(position);

                    break;


                default:

                    createdTile =
                        new EmptyTile(position);

                    break;
            }

            tiles[position.X, position.Y] =
                createdTile;

            return createdTile;
        }

        private Tile CreateTile(
           TileType type,
           int x,
           int y)
        {
            Position newPosition =
                new Position(x, y);

            return CreateTile(
                type,
                newPosition);
        }

        private void InitialiseTiles()
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (IsBoundary(x, y))
                    {
                        CreateTile(
                            TileType.Wall,
                            x,
                            y);
                    }
                    else
                    {
                        CreateTile(
                            TileType.Empty,
                            x,
                            y);
                    }
                }
            }
        }

        private Position GetRandomEmptyPosition()
        {
            while (true)
            {
                int x =
                    random.Next(1, width - 1);

                int y =
                    random.Next(1, height - 1);

                if (tiles[x, y] is EmptyTile)
                {
                    return new Position(x, y);
                }
            }
        }

        private void PlaceHero(HeroTile existingHero)
        {
            Position position = GetRandomEmptyPosition();

            if (existingHero == null)
            {
                hero =
                    (HeroTile)CreateTile( TileType.Hero, position);

                return;
            }
            hero = existingHero;
            hero.Position = position;

            tiles[position.X, position.Y] = hero;
        }

        private void PlaceExit()
        {
            Position position =
                GetRandomEmptyPosition();

            exit =
                (ExitTile)CreateTile(
                    TileType.Exit,
                    position);
        }

        public void SwapTiles(Tile firstTile, Tile secondTile)
        {
            int firstX = firstTile.X;
            int firstY = firstTile.Y;

            int secondX = secondTile.X;
            int secondY = secondTile.Y;

            
            firstTile.Position =
                new Position(secondX, secondY);

            secondTile.Position =
                new Position(firstX, firstY);

            
            tiles[firstTile.X, firstTile.Y] =
                firstTile;

            tiles[secondTile.X, secondTile.Y] =
                secondTile;
        }

        public override string ToString()
        {
            StringBuilder map =
                new StringBuilder();

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    map.Append(
                        tiles[x, y].Display);
                }

                map.AppendLine();
            }

            return map.ToString();
        }
    }
}



