﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA.GameForm;

namespace GADE_POE_HEENA_JANA
{
    internal abstract class CharacterTile: Tile
    {
        private int hitPoints;
        private int maximumHitPoints;
        private int attackPower;
        private Tile[] vision;

        protected CharacterTile(
            Position position,
            int hitPoints,
            int attackPower)
            : base(position)
        {
            this.hitPoints = hitPoints;
            this.maximumHitPoints = hitPoints;
            this.attackPower = attackPower;

            vision = new Tile[4];
        }

        public int HitPoints
        {
            get { return hitPoints; }
        }

        public int MaximumHitPoints
        {
            get { return maximumHitPoints; }
        }

        public int AttackPower
        {
            get { return attackPower; }
        }

        public Tile[] Vision
        {
            get { return vision; }
        }

        public void UpdateVision(Level level)
        {
            vision[0] = level.Tiles[X, Y - 1];
            vision[1] = level.Tiles[X + 1, Y];
            vision[2] = level.Tiles[X, Y + 1];
            vision[3] = level.Tiles[X - 1, Y];
        }

        public void TakeDamage(int amount)
        {
            hitPoints -= amount;

            if (hitPoints < 0)
            {
                hitPoints = 0;
            }
        }

        public void Attack(CharacterTile target)
        {
            target.TakeDamage(attackPower);
        }

        public bool IsDead
        {
            get
            {
                if (hitPoints > 0)
                {
                    return false;
                }

                return true;
            }
        }
    }
}

