﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA;

namespace GADE_POE_HEENA_JANA
{
 
    
        namespace GameForm
    {
       
        public abstract class Tile
        {
            private Position position;

            protected Tile(Position position)
            {
                this.position = position;
            }

            public Position Position
            {
                get { return position; }
                set { position = value; }
            }

            public int X
            {
                get { return position.X; }
            }

            public int Y
            {
                get { return position.Y; }
            }

            public abstract char Display
            {
                get;
            }
        }
    }
}