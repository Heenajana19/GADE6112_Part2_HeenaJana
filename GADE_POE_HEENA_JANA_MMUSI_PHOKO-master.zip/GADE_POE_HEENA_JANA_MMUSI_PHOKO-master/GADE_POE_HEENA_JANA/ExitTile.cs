﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA.GameForm;

namespace GADE_POE_HEENA_JANA

{
   
    public class ExitTile : Tile
    {
        public ExitTile(Position position)
            : base(position)
        {
        }

        public override char Display
        {
            get { return '▒'; }
        }
    }
}

