﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_POE_HEENA_JANA
{
    internal enum GameState
    {
        InProgress,
        Complete,
        GameOver
    }
}
