﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GADE_POE_HEENA_JANA;
using GADE_POE_HEENA_JANA.GameForm;

namespace GADE_POE_HEENA_JANA
{
    internal class GameEngine
    {
        private Level currentLevel;
        private int numberOfLevels;
        private Random random;

        private int currentLevelNumber;

        private GameState gameState;

        private const int MIN_SIZE = 10;
        private const int MAX_SIZE = 20;

        public GameEngine(int numberOfLevels)
        {
            this.numberOfLevels =
                numberOfLevels;

            random =
                new Random();

            currentLevelNumber = 1;

            gameState =
                GameState.InProgress;

            currentLevel =
                CreateNewLevel();
        }

        private Level CreateNewLevel(
           HeroTile existingHero = null)
        {
            int levelWidth =
                random.Next(
                    MIN_SIZE,
                    MAX_SIZE + 1);

            int levelHeight =
                random.Next(
                    MIN_SIZE,
                    MAX_SIZE + 1);

            return new Level(
                levelWidth,
                levelHeight,
                existingHero);
        }

        private void NextLevel()
        {
            HeroTile heroToTransfer =
                currentLevel.Hero;

            currentLevelNumber++;

            currentLevel =
                CreateNewLevel(
                    heroToTransfer);
        }

        private bool MoveHero(
           Direction direction)
        {
            if (direction == Direction.None)
            {
                return false;
            }

            int visionIndex =
                (int)direction;

            Tile destination =
                currentLevel.Hero
                .Vision[visionIndex];

            
            if (destination is ExitTile)
            {
                if (currentLevelNumber >= numberOfLevels)
                {
                    gameState =
                        GameState.Complete;

                    return false;
                }

                NextLevel();

                return true;
            }

            
            if (!(destination is EmptyTile))
            {
                return false;
            }

            currentLevel.SwapTiles(
                currentLevel.Hero,
                destination);

            currentLevel.Hero
                .UpdateVision(currentLevel);

            return true;
        }

        public void TriggerMovement(
            Direction direction)
        {
            MoveHero(direction);
        }

        public override string ToString()
        {
            switch (gameState)
            {
                case GameState.Complete:

                    return
                        "Congratulations! You completed all the levels!";


                case GameState.InProgress:

                    return
                        currentLevel.ToString();


                default:

                    return "Game Over!";
            }
        }
    }
}
