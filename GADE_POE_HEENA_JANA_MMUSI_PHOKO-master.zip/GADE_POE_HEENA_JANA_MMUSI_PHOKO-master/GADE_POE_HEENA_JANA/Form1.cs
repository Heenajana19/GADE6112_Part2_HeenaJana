﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GADE_POE_HEENA_JANA
{
    public partial class Form1 : Form
    {
        private GameEngine gameEngine;
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
            gameEngine =
               new GameEngine(10);
            UpdateDisplay();
        }

        private void UpdateDisplay()
        {
            label1.Text =
                gameEngine.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Direction direction =
               Direction.None;

            if (e.KeyCode == Keys.W)
            {
                direction =
                    Direction.Up;
            }
            else if (e.KeyCode == Keys.D)
            {
                direction =
                    Direction.Right;
            }
            else if (e.KeyCode == Keys.S)
            {
                direction =
                    Direction.Down;
            }
            else if (e.KeyCode == Keys.A)
            {
                direction =
                    Direction.Left;
            }

            
            if (direction == Direction.None)
            {
                return;
            }
            gameEngine.TriggerMovement(
              direction);

            UpdateDisplay();
        }
    }
}
